-- unnammed bootloader

local fs = require(game.ReplicatedStorage.Libraries.FileSystem)
local exe = require(game.ReplicatedStorage.Libraries.Executor)

-- Quick and dirty LEFDecoder
local function LEFDecode(str)
	local K, F = 1, 16385
	return (
		str:gsub("%x%x", function(c)
			local L = K % 274877906944 -- 2^38
			local H = (K - L) / 274877906944
			local M = H % 128
			c = tonumber(c, 16)
			local m = (c + (H - M) / 128) * (2 * M + 1) % 256
			K = L * F + H + c + m
			return string.char(m)
		end)
	)
end

local kernel = fs.GetFiles(fs.GetOSDriveLetter()..":/boot")[1] -- Hardcoded

exe.run(LEFDecode(kernel.Data), getfenv())()
